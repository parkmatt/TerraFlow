// Background service worker to proxy certain API requests from the content script.
// Runs with extension privileges (host_permissions in manifest.json) so it can fetch cross-origin
// without being blocked by the page's CORS restrictions.

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      if (!message || !message.type) return sendResponse({ ok: false, error: 'invalid_message' });

      if (message.type === 'PATCH_EVENT') {
        const { id, body, token } = message;
        const url = `https://events.terrain.scouts.com.au/events/${id}`;
        const headers = {
          'Content-Type': 'application/json',
        };
        if (token) headers['Authorization'] = token;

        const resp = await fetch(url, {
          method: 'PATCH',
          headers,
          body,
          // service worker fetch from extension is allowed by host_permissions
        });

        const text = await resp.text();
        sendResponse({ ok: resp.ok, status: resp.status, body: text });
        return;
      }

      if (message.type === 'POST_EVENT') {
        const { url, body, token, method = 'POST' } = message;
        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = token;
        const resp = await fetch(url, { method, headers, body });
        const text = await resp.text();
        sendResponse({ ok: resp.ok, status: resp.status, body: text });
        return;
      }

      sendResponse({ ok: false, error: 'unknown_type' });
    } catch (err) {
      sendResponse({ ok: false, error: String(err) });
    }
  })();
  // Must return true to indicate we'll send an async response
  return true;
});
