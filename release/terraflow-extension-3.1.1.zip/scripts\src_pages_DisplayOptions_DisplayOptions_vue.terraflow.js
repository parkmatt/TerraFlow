"use strict";
(self["webpackChunkterrain_terraflow"] = self["webpackChunkterrain_terraflow"] || []).push([["src_pages_DisplayOptions_DisplayOptions_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-1.use!./src/pages/DisplayOptions/DisplayOptions.ts?vue&type=script&lang=js&external":
/*!***************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-1.use!./src/pages/DisplayOptions/DisplayOptions.ts?vue&type=script&lang=js&external ***!
  \***************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_EVENT_SETTINGS: () => (/* binding */ DEFAULT_EVENT_SETTINGS),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getStoredEventSetting: () => (/* binding */ getStoredEventSetting),
/* harmony export */   storeEventSetting: () => (/* binding */ storeEventSetting)
/* harmony export */ });
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.esm.js");


// Default event settings interface

// Default values
const DEFAULT_EVENT_SETTINGS = {
  startTime: "19:00",
  // 7pm
  duration: 90,
  // 90 minutes
  location: "" // empty default location
};

// Helper functions
const getStoredEventSetting = (key, defaultValue) => {
  const stored = localStorage.getItem("summit_event_".concat(key));
  return stored ? key === 'duration' ? parseInt(stored) : stored : defaultValue;
};
const storeEventSetting = (key, value) => {
  localStorage.setItem("summit_event_".concat(key), value.toString());
  // Dispatch event for other components to listen to
  window.dispatchEvent(new CustomEvent('summitEventSettingsChanged', {
    detail: {
      key,
      value
    }
  }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,vue__WEBPACK_IMPORTED_MODULE_0__.defineComponent)({
  data() {
    return {
      // Local data property to store the message
      helpbutton: this.$store.state.Summit.helpButton,
      // Event default settings
      defaultStartTime: getStoredEventSetting('startTime', DEFAULT_EVENT_SETTINGS.startTime),
      defaultDuration: getStoredEventSetting('duration', DEFAULT_EVENT_SETTINGS.duration),
      defaultLocation: getStoredEventSetting('location', DEFAULT_EVENT_SETTINGS.location)
    };
  },
  methods: {
    updateHelpButton() {
      this.$store.dispatch("Summit/toggleHelpButton", this.helpbutton);
      console.log("Help button updated to " + this.helpbutton);
    },
    updateDefaultStartTime() {
      storeEventSetting('startTime', this.defaultStartTime);
      console.log("Default start time updated to " + this.defaultStartTime);
    },
    updateDefaultDuration() {
      storeEventSetting('duration', this.defaultDuration);
      console.log("Default duration updated to " + this.defaultDuration + " minutes");
    },
    updateDefaultLocation() {
      storeEventSetting('location', this.defaultLocation);
      console.log("Default location updated to " + this.defaultLocation);
    }
  },
  computed: {
    // Computed property to get the message from Vuex
    computedMessage() {
      return this.$store.getters["Summit/getHelpButton"];
    }
  },
  watch: {
    // Watch for changes in Vuex state
    "$store.state.Summit.helpButton": function (newVal) {
      this.helpbutton = newVal;
    }
  },
  mounted() {
    // Initialize local message from Vuex store
    this.helpbutton = this.$store.state.Summit.helpButton;
    window.$nuxt.$store.state.global.breadcrumbs = [{
      text: "Summit",
      disabled: false,
      to: "/summit/home",
      exact: true
    }, {
      text: "Tools",
      disabled: true,
      to: "/summit/tools",
      exact: true
    }, {
      text: "Options",
      disabled: true,
      to: "/summit/tools/DisplayOptions",
      exact: true
    }];
  }
  // Include other methods as needed...
}));

// Export the helper functions for use in other components


/***/ }),

/***/ "./src/pages/DisplayOptions/DisplayOptions.vue":
/*!*****************************************************!*\
  !*** ./src/pages/DisplayOptions/DisplayOptions.vue ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_EVENT_SETTINGS: () => (/* reexport safe */ _DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__.DEFAULT_EVENT_SETTINGS),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getStoredEventSetting: () => (/* reexport safe */ _DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__.getStoredEventSetting),
/* harmony export */   storeEventSetting: () => (/* reexport safe */ _DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__.storeEventSetting)
/* harmony export */ });
/* harmony import */ var _DisplayOptions_vue_vue_type_template_id_266959ca_scoped_true__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DisplayOptions.vue?vue&type=template&id=266959ca&scoped=true */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/pages/DisplayOptions/DisplayOptions.vue?vue&type=template&id=266959ca&scoped=true");
/* harmony import */ var _DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DisplayOptions.ts?vue&type=script&lang=js&external */ "./src/pages/DisplayOptions/DisplayOptions.ts?vue&type=script&lang=js&external");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");



;


/* normalize component */

var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  _DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__["default"],
  _DisplayOptions_vue_vue_type_template_id_266959ca_scoped_true__WEBPACK_IMPORTED_MODULE_2__.render,
  _DisplayOptions_vue_vue_type_template_id_266959ca_scoped_true__WEBPACK_IMPORTED_MODULE_2__.staticRenderFns,
  false,
  null,
  "266959ca",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "src/pages/DisplayOptions/DisplayOptions.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./src/pages/DisplayOptions/DisplayOptions.ts?vue&type=script&lang=js&external":
/*!*************************************************************************************!*\
  !*** ./src/pages/DisplayOptions/DisplayOptions.ts?vue&type=script&lang=js&external ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DEFAULT_EVENT_SETTINGS: () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_1_use_DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__.DEFAULT_EVENT_SETTINGS),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getStoredEventSetting: () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_1_use_DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__.getStoredEventSetting),
/* harmony export */   storeEventSetting: () => (/* reexport safe */ _node_modules_babel_loader_lib_index_js_clonedRuleSet_1_use_DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__.storeEventSetting)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_1_use_DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-1.use!./DisplayOptions.ts?vue&type=script&lang=js&external */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-1.use!./src/pages/DisplayOptions/DisplayOptions.ts?vue&type=script&lang=js&external");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_1_use_DisplayOptions_ts_vue_type_script_lang_js_external__WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/pages/DisplayOptions/DisplayOptions.vue?vue&type=template&id=266959ca&scoped=true":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??ruleSet[1].rules[2]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./src/pages/DisplayOptions/DisplayOptions.vue?vue&type=template&id=266959ca&scoped=true ***!
  \***************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* binding */ render),
/* harmony export */   staticRenderFns: () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function render(){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"options-container",attrs:{"id":"optionsDiv"}},[_vm._m(0),_vm._v(" "),_c('div',{staticClass:"options-form"},[_c('div',{staticClass:"option-section"},[_c('h2',{staticClass:"section-title"},[_vm._v("Display Settings")]),_vm._v(" "),_c('div',{staticClass:"section-content"},[_c('div',{staticClass:"setting-row",attrs:{"title":"Display the floating help button on Terrain pages"}},[_vm._m(1),_vm._v(" "),_c('div',{staticClass:"setting-control"},[_c('label',{staticClass:"checkbox-container"},[_c('input',{attrs:{"type":"checkbox","name":"helpbutton","id":"helpbutton"},domProps:{"checked":_vm.helpbutton},on:{"change":_vm.updateHelpButton}}),_vm._v(" "),_c('span',{staticClass:"checkmark"}),_vm._v(" "),_c('span',{staticClass:"checkbox-label"},[_vm._v("Show help button")])])])])])]),_vm._v(" "),_c('div',{staticClass:"option-section"},[_c('h2',{staticClass:"section-title"},[_vm._v("Event Default Settings")]),_vm._v(" "),_c('div',{staticClass:"section-content"},[_c('div',{staticClass:"setting-row",attrs:{"title":"The default time for new calendar events"}},[_vm._m(2),_vm._v(" "),_c('div',{staticClass:"setting-control"},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.defaultStartTime),expression:"defaultStartTime"}],staticClass:"input-field time-input",attrs:{"type":"time","id":"defaultStartTime"},domProps:{"value":(_vm.defaultStartTime)},on:{"change":_vm.updateDefaultStartTime,"input":function($event){if($event.target.composing)return;_vm.defaultStartTime=$event.target.value}}})])]),_vm._v(" "),_c('div',{staticClass:"setting-row",attrs:{"title":"How long new events should last (in minutes)"}},[_vm._m(3),_vm._v(" "),_c('div',{staticClass:"setting-control"},[_c('div',{staticClass:"input-group"},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.defaultDuration),expression:"defaultDuration"}],staticClass:"input-field number-input",attrs:{"type":"number","id":"defaultDuration","min":"15","max":"1440","step":"15"},domProps:{"value":(_vm.defaultDuration)},on:{"change":_vm.updateDefaultDuration,"input":function($event){if($event.target.composing)return;_vm.defaultDuration=$event.target.value}}}),_vm._v(" "),_c('span',{staticClass:"input-addon"},[_vm._v("minutes")])])])]),_vm._v(" "),_c('div',{staticClass:"setting-row",attrs:{"title":"The default location for new calendar events"}},[_vm._m(4),_vm._v(" "),_c('div',{staticClass:"setting-control"},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.defaultLocation),expression:"defaultLocation"}],staticClass:"input-field text-input",attrs:{"type":"text","id":"defaultLocation","placeholder":"Enter default location"},domProps:{"value":(_vm.defaultLocation)},on:{"change":_vm.updateDefaultLocation,"input":function($event){if($event.target.composing)return;_vm.defaultLocation=$event.target.value}}})])])])])])])
}
var staticRenderFns = [function (){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"page-header"},[_c('h1',{staticClass:"page-title"},[_vm._v("Options")]),_vm._v(" "),_c('p',{staticClass:"page-description"},[_vm._v("\n      Configure how Summit looks and behaves. Settings are saved locally in your browser.\n    ")])])
},function (){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"setting-label"},[_c('label',{attrs:{"for":"helpbutton"}},[_vm._v("Terrain Help Button")])])
},function (){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"setting-label"},[_c('label',{attrs:{"for":"defaultStartTime"}},[_vm._v("Default Start Time")])])
},function (){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"setting-label"},[_c('label',{attrs:{"for":"defaultDuration"}},[_vm._v("Default Duration")])])
},function (){var _vm=this,_c=_vm._self._c,_setup=_vm._self._setupProxy;return _c('div',{staticClass:"setting-label"},[_c('label',{attrs:{"for":"defaultLocation"}},[_vm._v("Default Location")])])
}]
render._withStripped = true


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2NyaXB0cy9zcmNfcGFnZXNfRGlzcGxheU9wdGlvbnNfRGlzcGxheU9wdGlvbnNfdnVlLnRlcnJhZmxvdy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQ3NDOztBQUV0Qzs7QUFPQTtBQUNBLE1BQU1DLHNCQUE0QyxHQUFHO0VBQ25EQyxTQUFTLEVBQUUsT0FBTztFQUFFO0VBQ3BCQyxRQUFRLEVBQUUsRUFBRTtFQUFFO0VBQ2RDLFFBQVEsRUFBRSxFQUFFLENBQUM7QUFDZixDQUFDOztBQUVEO0FBQ0EsTUFBTUMscUJBQXFCLEdBQUdBLENBQUNDLEdBQStCLEVBQUVDLFlBQWlCLEtBQUs7RUFDcEYsTUFBTUMsTUFBTSxHQUFHQyxZQUFZLENBQUNDLE9BQU8saUJBQUFDLE1BQUEsQ0FBaUJMLEdBQUcsQ0FBRSxDQUFDO0VBQzFELE9BQU9FLE1BQU0sR0FBSUYsR0FBRyxLQUFLLFVBQVUsR0FBR00sUUFBUSxDQUFDSixNQUFNLENBQUMsR0FBR0EsTUFBTSxHQUFJRCxZQUFZO0FBQ2pGLENBQUM7QUFFRCxNQUFNTSxpQkFBaUIsR0FBR0EsQ0FBQ1AsR0FBK0IsRUFBRVEsS0FBVSxLQUFLO0VBQ3pFTCxZQUFZLENBQUNNLE9BQU8saUJBQUFKLE1BQUEsQ0FBaUJMLEdBQUcsR0FBSVEsS0FBSyxDQUFDRSxRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQzdEO0VBQ0FDLE1BQU0sQ0FBQ0MsYUFBYSxDQUFDLElBQUlDLFdBQVcsQ0FBQyw0QkFBNEIsRUFBRTtJQUNqRUMsTUFBTSxFQUFFO01BQUVkLEdBQUc7TUFBRVE7SUFBTTtFQUN2QixDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFFRCxpRUFBZWQsb0RBQWUsQ0FBQztFQUM3QnFCLElBQUlBLENBQUEsRUFBRztJQUNMLE9BQU87TUFDTDtNQUNBQyxVQUFVLEVBQUUsSUFBSSxDQUFDQyxNQUFNLENBQUNDLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxVQUFVO01BQy9DO01BQ0FDLGdCQUFnQixFQUFFdEIscUJBQXFCLENBQUMsV0FBVyxFQUFFSixzQkFBc0IsQ0FBQ0MsU0FBUyxDQUFDO01BQ3RGMEIsZUFBZSxFQUFFdkIscUJBQXFCLENBQUMsVUFBVSxFQUFFSixzQkFBc0IsQ0FBQ0UsUUFBUSxDQUFDO01BQ25GMEIsZUFBZSxFQUFFeEIscUJBQXFCLENBQUMsVUFBVSxFQUFFSixzQkFBc0IsQ0FBQ0csUUFBUTtJQUNwRixDQUFDO0VBQ0gsQ0FBQztFQUNEMEIsT0FBTyxFQUFFO0lBQ1BDLGdCQUFnQkEsQ0FBQSxFQUFHO01BQ2pCLElBQUksQ0FBQ1IsTUFBTSxDQUFDUyxRQUFRLENBQUMseUJBQXlCLEVBQUUsSUFBSSxDQUFDVixVQUFVLENBQUM7TUFDaEVXLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQ1osVUFBVSxDQUFDO0lBQzFELENBQUM7SUFFRGEsc0JBQXNCQSxDQUFBLEVBQUc7TUFDdkJ0QixpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDYyxnQkFBZ0IsQ0FBQztNQUNyRE0sT0FBTyxDQUFDQyxHQUFHLENBQUMsZ0NBQWdDLEdBQUcsSUFBSSxDQUFDUCxnQkFBZ0IsQ0FBQztJQUN2RSxDQUFDO0lBRURTLHFCQUFxQkEsQ0FBQSxFQUFHO01BQ3RCdkIsaUJBQWlCLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQ2UsZUFBZSxDQUFDO01BQ25ESyxPQUFPLENBQUNDLEdBQUcsQ0FBQyw4QkFBOEIsR0FBRyxJQUFJLENBQUNOLGVBQWUsR0FBRyxVQUFVLENBQUM7SUFDakYsQ0FBQztJQUVEUyxxQkFBcUJBLENBQUEsRUFBRztNQUN0QnhCLGlCQUFpQixDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUNnQixlQUFlLENBQUM7TUFDbkRJLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLDhCQUE4QixHQUFHLElBQUksQ0FBQ0wsZUFBZSxDQUFDO0lBQ3BFO0VBQ0YsQ0FBQztFQUVEUyxRQUFRLEVBQUU7SUFDUjtJQUNBQyxlQUFlQSxDQUFBLEVBQUc7TUFDaEIsT0FBTyxJQUFJLENBQUNoQixNQUFNLENBQUNpQixPQUFPLENBQUMsc0JBQXNCLENBQUM7SUFDcEQ7RUFDRixDQUFDO0VBQ0RDLEtBQUssRUFBRTtJQUNMO0lBQ0EsZ0NBQWdDLEVBQUUsU0FBQUMsQ0FBVUMsTUFBTSxFQUFFO01BQ2xELElBQUksQ0FBQ3JCLFVBQVUsR0FBR3FCLE1BQU07SUFDMUI7RUFDRixDQUFDO0VBQ0RDLE9BQU9BLENBQUEsRUFBRztJQUNSO0lBQ0EsSUFBSSxDQUFDdEIsVUFBVSxHQUFHLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLLENBQUNDLE1BQU0sQ0FBQ0MsVUFBVTtJQUNwRFQsTUFBTSxDQUFDNEIsS0FBSyxDQUFDdEIsTUFBTSxDQUFDQyxLQUFLLENBQXNCc0IsTUFBTSxDQUFDQyxXQUFXLEdBQUcsQ0FDbkU7TUFDRUMsSUFBSSxFQUFFLFFBQVE7TUFDZEMsUUFBUSxFQUFFLEtBQUs7TUFDZkMsRUFBRSxFQUFFLGNBQWM7TUFDbEJDLEtBQUssRUFBRTtJQUNULENBQUMsRUFDRDtNQUNFSCxJQUFJLEVBQUUsT0FBTztNQUNiQyxRQUFRLEVBQUUsSUFBSTtNQUNkQyxFQUFFLEVBQUUsZUFBZTtNQUNuQkMsS0FBSyxFQUFFO0lBQ1QsQ0FBQyxFQUNEO01BQ0VILElBQUksRUFBRSxTQUFTO01BQ2ZDLFFBQVEsRUFBRSxJQUFJO01BQ2RDLEVBQUUsRUFBRSw4QkFBOEI7TUFDbENDLEtBQUssRUFBRTtJQUNULENBQUMsQ0FDRjtFQUNIO0VBQ0E7QUFDRixDQUFDLENBQUMsRUFBQzs7QUFFSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkd3RztBQUMvQjtBQUNMO0FBQ3BFLENBQWlHOzs7QUFHakc7QUFDNkY7QUFDN0YsZ0JBQWdCLHVHQUFVO0FBQzFCLEVBQUUsMkZBQU07QUFDUixFQUFFLGlHQUFNO0FBQ1IsRUFBRSwwR0FBZTtBQUNqQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQSxJQUFJLEtBQVUsRUFBRSxZQWlCZjtBQUNEO0FBQ0EsaUVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkMrSCxDQUFDLGlFQUFlLHNKQUFHLEVBQUM7Ozs7Ozs7Ozs7Ozs7O0FDQWxLLCtCQUErQiwwREFBMEQsaUJBQWlCLHVDQUF1QyxtQkFBbUIsa0NBQWtDLDJCQUEyQixZQUFZLDZCQUE2QixXQUFXLDRCQUE0QixxREFBcUQsOEJBQThCLFlBQVksaUNBQWlDLDZEQUE2RCxrQ0FBa0MsOEJBQThCLGNBQWMsaUNBQWlDLGNBQWMsT0FBTyx3REFBd0QsV0FBVyx5QkFBeUIsS0FBSywrQkFBK0IseUJBQXlCLHdCQUF3Qix5QkFBeUIsNkJBQTZCLCtEQUErRCw2QkFBNkIsV0FBVyw0QkFBNEIsMkRBQTJELDhCQUE4QixZQUFZLGlDQUFpQyxvREFBb0Qsa0NBQWtDLDhCQUE4QixjQUFjLGFBQWEsMEZBQTBGLDhDQUE4QyxzQ0FBc0MsV0FBVywrQkFBK0IsS0FBSyw2REFBNkQsa0NBQWtDLDJDQUEyQyw0QkFBNEIsaUNBQWlDLHdEQUF3RCxrQ0FBa0MsOEJBQThCLFlBQVksMEJBQTBCLGNBQWMsYUFBYSx3RkFBd0YsZ0RBQWdELDJFQUEyRSxXQUFXLDhCQUE4QixLQUFLLDREQUE0RCxrQ0FBa0MsMENBQTBDLHlCQUF5QiwwQkFBMEIsa0RBQWtELGlDQUFpQyx3REFBd0Qsa0NBQWtDLDhCQUE4QixjQUFjLGFBQWEsd0ZBQXdGLDhDQUE4Qyw0RUFBNEUsV0FBVyw4QkFBOEIsS0FBSyw0REFBNEQsa0NBQWtDLDBDQUEwQztBQUN4M0Y7QUFDQSxtQ0FBbUMsMERBQTBELGlCQUFpQiwwQkFBMEIsV0FBVyx5QkFBeUIsMENBQTBDLCtCQUErQjtBQUNyUCxDQUFDLGFBQWEsMERBQTBELGlCQUFpQiw0QkFBNEIsY0FBYyxPQUFPLG9CQUFvQjtBQUM5SixDQUFDLGFBQWEsMERBQTBELGlCQUFpQiw0QkFBNEIsY0FBYyxPQUFPLDBCQUEwQjtBQUNwSyxDQUFDLGFBQWEsMERBQTBELGlCQUFpQiw0QkFBNEIsY0FBYyxPQUFPLHlCQUF5QjtBQUNuSyxDQUFDLGFBQWEsMERBQTBELGlCQUFpQiw0QkFBNEIsY0FBYyxPQUFPLHlCQUF5QjtBQUNuSyxDQUFDO0FBQ0QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly90ZXJyYWluLXRlcnJhZmxvdy8uL3NyYy9wYWdlcy9EaXNwbGF5T3B0aW9ucy9EaXNwbGF5T3B0aW9ucy50cyIsIndlYnBhY2s6Ly90ZXJyYWluLXRlcnJhZmxvdy8uL3NyYy9wYWdlcy9EaXNwbGF5T3B0aW9ucy9EaXNwbGF5T3B0aW9ucy52dWUiLCJ3ZWJwYWNrOi8vdGVycmFpbi10ZXJyYWZsb3cvLi9zcmMvcGFnZXMvRGlzcGxheU9wdGlvbnMvRGlzcGxheU9wdGlvbnMudHM/MDk1OCIsIndlYnBhY2s6Ly90ZXJyYWluLXRlcnJhZmxvdy8uL3NyYy9wYWdlcy9EaXNwbGF5T3B0aW9ucy9EaXNwbGF5T3B0aW9ucy52dWU/MGFiYiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBUZXJyYWluUm9vdFN0YXRlIH0gZnJvbSBcIkAvdHlwZXMvdGVycmFpblN0YXRlXCI7XHJcbmltcG9ydCB7IGRlZmluZUNvbXBvbmVudCB9IGZyb20gXCJ2dWVcIjtcclxuXHJcbi8vIERlZmF1bHQgZXZlbnQgc2V0dGluZ3MgaW50ZXJmYWNlXHJcbmludGVyZmFjZSBFdmVudERlZmF1bHRTZXR0aW5ncyB7XHJcbiAgc3RhcnRUaW1lOiBzdHJpbmc7XHJcbiAgZHVyYXRpb246IG51bWJlcjtcclxuICBsb2NhdGlvbjogc3RyaW5nO1xyXG59XHJcblxyXG4vLyBEZWZhdWx0IHZhbHVlc1xyXG5jb25zdCBERUZBVUxUX0VWRU5UX1NFVFRJTkdTOiBFdmVudERlZmF1bHRTZXR0aW5ncyA9IHtcclxuICBzdGFydFRpbWU6IFwiMTk6MDBcIiwgLy8gN3BtXHJcbiAgZHVyYXRpb246IDkwLCAvLyA5MCBtaW51dGVzXHJcbiAgbG9jYXRpb246IFwiXCIgLy8gZW1wdHkgZGVmYXVsdCBsb2NhdGlvblxyXG59O1xyXG5cclxuLy8gSGVscGVyIGZ1bmN0aW9uc1xyXG5jb25zdCBnZXRTdG9yZWRFdmVudFNldHRpbmcgPSAoa2V5OiBrZXlvZiBFdmVudERlZmF1bHRTZXR0aW5ncywgZGVmYXVsdFZhbHVlOiBhbnkpID0+IHtcclxuICBjb25zdCBzdG9yZWQgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShgc3VtbWl0X2V2ZW50XyR7a2V5fWApO1xyXG4gIHJldHVybiBzdG9yZWQgPyAoa2V5ID09PSAnZHVyYXRpb24nID8gcGFyc2VJbnQoc3RvcmVkKSA6IHN0b3JlZCkgOiBkZWZhdWx0VmFsdWU7XHJcbn07XHJcblxyXG5jb25zdCBzdG9yZUV2ZW50U2V0dGluZyA9IChrZXk6IGtleW9mIEV2ZW50RGVmYXVsdFNldHRpbmdzLCB2YWx1ZTogYW55KSA9PiB7XHJcbiAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oYHN1bW1pdF9ldmVudF8ke2tleX1gLCB2YWx1ZS50b1N0cmluZygpKTtcclxuICAvLyBEaXNwYXRjaCBldmVudCBmb3Igb3RoZXIgY29tcG9uZW50cyB0byBsaXN0ZW4gdG9cclxuICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoJ3N1bW1pdEV2ZW50U2V0dGluZ3NDaGFuZ2VkJywge1xyXG4gICAgZGV0YWlsOiB7IGtleSwgdmFsdWUgfVxyXG4gIH0pKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbXBvbmVudCh7XHJcbiAgZGF0YSgpIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIC8vIExvY2FsIGRhdGEgcHJvcGVydHkgdG8gc3RvcmUgdGhlIG1lc3NhZ2VcclxuICAgICAgaGVscGJ1dHRvbjogdGhpcy4kc3RvcmUuc3RhdGUuU3VtbWl0LmhlbHBCdXR0b24sXHJcbiAgICAgIC8vIEV2ZW50IGRlZmF1bHQgc2V0dGluZ3NcclxuICAgICAgZGVmYXVsdFN0YXJ0VGltZTogZ2V0U3RvcmVkRXZlbnRTZXR0aW5nKCdzdGFydFRpbWUnLCBERUZBVUxUX0VWRU5UX1NFVFRJTkdTLnN0YXJ0VGltZSksXHJcbiAgICAgIGRlZmF1bHREdXJhdGlvbjogZ2V0U3RvcmVkRXZlbnRTZXR0aW5nKCdkdXJhdGlvbicsIERFRkFVTFRfRVZFTlRfU0VUVElOR1MuZHVyYXRpb24pLFxyXG4gICAgICBkZWZhdWx0TG9jYXRpb246IGdldFN0b3JlZEV2ZW50U2V0dGluZygnbG9jYXRpb24nLCBERUZBVUxUX0VWRU5UX1NFVFRJTkdTLmxvY2F0aW9uKSxcclxuICAgIH07XHJcbiAgfSxcclxuICBtZXRob2RzOiB7XHJcbiAgICB1cGRhdGVIZWxwQnV0dG9uKCkge1xyXG4gICAgICB0aGlzLiRzdG9yZS5kaXNwYXRjaChcIlN1bW1pdC90b2dnbGVIZWxwQnV0dG9uXCIsIHRoaXMuaGVscGJ1dHRvbik7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiSGVscCBidXR0b24gdXBkYXRlZCB0byBcIiArIHRoaXMuaGVscGJ1dHRvbik7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICB1cGRhdGVEZWZhdWx0U3RhcnRUaW1lKCkge1xyXG4gICAgICBzdG9yZUV2ZW50U2V0dGluZygnc3RhcnRUaW1lJywgdGhpcy5kZWZhdWx0U3RhcnRUaW1lKTtcclxuICAgICAgY29uc29sZS5sb2coXCJEZWZhdWx0IHN0YXJ0IHRpbWUgdXBkYXRlZCB0byBcIiArIHRoaXMuZGVmYXVsdFN0YXJ0VGltZSk7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICB1cGRhdGVEZWZhdWx0RHVyYXRpb24oKSB7XHJcbiAgICAgIHN0b3JlRXZlbnRTZXR0aW5nKCdkdXJhdGlvbicsIHRoaXMuZGVmYXVsdER1cmF0aW9uKTtcclxuICAgICAgY29uc29sZS5sb2coXCJEZWZhdWx0IGR1cmF0aW9uIHVwZGF0ZWQgdG8gXCIgKyB0aGlzLmRlZmF1bHREdXJhdGlvbiArIFwiIG1pbnV0ZXNcIik7XHJcbiAgICB9LFxyXG4gICAgXHJcbiAgICB1cGRhdGVEZWZhdWx0TG9jYXRpb24oKSB7XHJcbiAgICAgIHN0b3JlRXZlbnRTZXR0aW5nKCdsb2NhdGlvbicsIHRoaXMuZGVmYXVsdExvY2F0aW9uKTtcclxuICAgICAgY29uc29sZS5sb2coXCJEZWZhdWx0IGxvY2F0aW9uIHVwZGF0ZWQgdG8gXCIgKyB0aGlzLmRlZmF1bHRMb2NhdGlvbik7XHJcbiAgICB9XHJcbiAgfSxcclxuXHJcbiAgY29tcHV0ZWQ6IHtcclxuICAgIC8vIENvbXB1dGVkIHByb3BlcnR5IHRvIGdldCB0aGUgbWVzc2FnZSBmcm9tIFZ1ZXhcclxuICAgIGNvbXB1dGVkTWVzc2FnZSgpIHtcclxuICAgICAgcmV0dXJuIHRoaXMuJHN0b3JlLmdldHRlcnNbXCJTdW1taXQvZ2V0SGVscEJ1dHRvblwiXTtcclxuICAgIH0sXHJcbiAgfSxcclxuICB3YXRjaDoge1xyXG4gICAgLy8gV2F0Y2ggZm9yIGNoYW5nZXMgaW4gVnVleCBzdGF0ZVxyXG4gICAgXCIkc3RvcmUuc3RhdGUuU3VtbWl0LmhlbHBCdXR0b25cIjogZnVuY3Rpb24gKG5ld1ZhbCkge1xyXG4gICAgICB0aGlzLmhlbHBidXR0b24gPSBuZXdWYWw7XHJcbiAgICB9LFxyXG4gIH0sXHJcbiAgbW91bnRlZCgpIHtcclxuICAgIC8vIEluaXRpYWxpemUgbG9jYWwgbWVzc2FnZSBmcm9tIFZ1ZXggc3RvcmVcclxuICAgIHRoaXMuaGVscGJ1dHRvbiA9IHRoaXMuJHN0b3JlLnN0YXRlLlN1bW1pdC5oZWxwQnV0dG9uO1xyXG4gICAgKHdpbmRvdy4kbnV4dC4kc3RvcmUuc3RhdGUgYXMgVGVycmFpblJvb3RTdGF0ZSkuZ2xvYmFsLmJyZWFkY3J1bWJzID0gW1xyXG4gICAgICB7XHJcbiAgICAgICAgdGV4dDogXCJTdW1taXRcIixcclxuICAgICAgICBkaXNhYmxlZDogZmFsc2UsXHJcbiAgICAgICAgdG86IFwiL3N1bW1pdC9ob21lXCIsXHJcbiAgICAgICAgZXhhY3Q6IHRydWUsXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICB0ZXh0OiBcIlRvb2xzXCIsXHJcbiAgICAgICAgZGlzYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgdG86IFwiL3N1bW1pdC90b29sc1wiLFxyXG4gICAgICAgIGV4YWN0OiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgdGV4dDogXCJPcHRpb25zXCIsXHJcbiAgICAgICAgZGlzYWJsZWQ6IHRydWUsXHJcbiAgICAgICAgdG86IFwiL3N1bW1pdC90b29scy9EaXNwbGF5T3B0aW9uc1wiLFxyXG4gICAgICAgIGV4YWN0OiB0cnVlLFxyXG4gICAgICB9LFxyXG4gICAgXTtcclxuICB9LFxyXG4gIC8vIEluY2x1ZGUgb3RoZXIgbWV0aG9kcyBhcyBuZWVkZWQuLi5cclxufSk7XHJcblxyXG4vLyBFeHBvcnQgdGhlIGhlbHBlciBmdW5jdGlvbnMgZm9yIHVzZSBpbiBvdGhlciBjb21wb25lbnRzXHJcbmV4cG9ydCB7IGdldFN0b3JlZEV2ZW50U2V0dGluZywgc3RvcmVFdmVudFNldHRpbmcsIERFRkFVTFRfRVZFTlRfU0VUVElOR1MgfTtcclxuIiwiaW1wb3J0IHsgcmVuZGVyLCBzdGF0aWNSZW5kZXJGbnMgfSBmcm9tIFwiLi9EaXNwbGF5T3B0aW9ucy52dWU/dnVlJnR5cGU9dGVtcGxhdGUmaWQ9MjY2OTU5Y2Emc2NvcGVkPXRydWVcIlxuaW1wb3J0IHNjcmlwdCBmcm9tIFwiLi9EaXNwbGF5T3B0aW9ucy50cz92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcyZleHRlcm5hbFwiXG5leHBvcnQgKiBmcm9tIFwiLi9EaXNwbGF5T3B0aW9ucy50cz92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcyZleHRlcm5hbFwiXG5pbXBvcnQgc3R5bGUwIGZyb20gXCIuL0Rpc3BsYXlPcHRpb25zLnZ1ZT92dWUmdHlwZT1zdHlsZSZpbmRleD0wJmlkPTI2Njk1OWNhJnNjb3BlZD10cnVlJmxhbmc9Y3NzXCJcblxuXG4vKiBub3JtYWxpemUgY29tcG9uZW50ICovXG5pbXBvcnQgbm9ybWFsaXplciBmcm9tIFwiIS4uLy4uLy4uL25vZGVfbW9kdWxlcy92dWUtbG9hZGVyL2xpYi9ydW50aW1lL2NvbXBvbmVudE5vcm1hbGl6ZXIuanNcIlxudmFyIGNvbXBvbmVudCA9IG5vcm1hbGl6ZXIoXG4gIHNjcmlwdCxcbiAgcmVuZGVyLFxuICBzdGF0aWNSZW5kZXJGbnMsXG4gIGZhbHNlLFxuICBudWxsLFxuICBcIjI2Njk1OWNhXCIsXG4gIG51bGxcbiAgXG4pXG5cbi8qIGhvdCByZWxvYWQgKi9cbmlmIChtb2R1bGUuaG90KSB7XG4gIHZhciBhcGkgPSByZXF1aXJlKFwiQzpcXFxcVXNlcnNcXFxcbWF0dFxcXFwzLlNjb3V0Rmxvd1xcXFxTdW1taXRcXFxcbm9kZV9tb2R1bGVzXFxcXHZ1ZS1ob3QtcmVsb2FkLWFwaVxcXFxkaXN0XFxcXGluZGV4LmpzXCIpXG4gIGFwaS5pbnN0YWxsKHJlcXVpcmUoJ3Z1ZScpKVxuICBpZiAoYXBpLmNvbXBhdGlibGUpIHtcbiAgICBtb2R1bGUuaG90LmFjY2VwdCgpXG4gICAgaWYgKCFhcGkuaXNSZWNvcmRlZCgnMjY2OTU5Y2EnKSkge1xuICAgICAgYXBpLmNyZWF0ZVJlY29yZCgnMjY2OTU5Y2EnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9IGVsc2Uge1xuICAgICAgYXBpLnJlbG9hZCgnMjY2OTU5Y2EnLCBjb21wb25lbnQub3B0aW9ucylcbiAgICB9XG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoXCIuL0Rpc3BsYXlPcHRpb25zLnZ1ZT92dWUmdHlwZT10ZW1wbGF0ZSZpZD0yNjY5NTljYSZzY29wZWQ9dHJ1ZVwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICBhcGkucmVyZW5kZXIoJzI2Njk1OWNhJywge1xuICAgICAgICByZW5kZXI6IHJlbmRlcixcbiAgICAgICAgc3RhdGljUmVuZGVyRm5zOiBzdGF0aWNSZW5kZXJGbnNcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxufVxuY29tcG9uZW50Lm9wdGlvbnMuX19maWxlID0gXCJzcmMvcGFnZXMvRGlzcGxheU9wdGlvbnMvRGlzcGxheU9wdGlvbnMudnVlXCJcbmV4cG9ydCBkZWZhdWx0IGNvbXBvbmVudC5leHBvcnRzIiwiaW1wb3J0IG1vZCBmcm9tIFwiLSEuLi8uLi8uLi9ub2RlX21vZHVsZXMvYmFiZWwtbG9hZGVyL2xpYi9pbmRleC5qcz8/Y2xvbmVkUnVsZVNldC0xLnVzZSEuL0Rpc3BsYXlPcHRpb25zLnRzP3Z1ZSZ0eXBlPXNjcmlwdCZsYW5nPWpzJmV4dGVybmFsXCI7IGV4cG9ydCBkZWZhdWx0IG1vZDsgZXhwb3J0ICogZnJvbSBcIi0hLi4vLi4vLi4vbm9kZV9tb2R1bGVzL2JhYmVsLWxvYWRlci9saWIvaW5kZXguanM/P2Nsb25lZFJ1bGVTZXQtMS51c2UhLi9EaXNwbGF5T3B0aW9ucy50cz92dWUmdHlwZT1zY3JpcHQmbGFuZz1qcyZleHRlcm5hbFwiIiwidmFyIHJlbmRlciA9IGZ1bmN0aW9uIHJlbmRlcigpe3ZhciBfdm09dGhpcyxfYz1fdm0uX3NlbGYuX2MsX3NldHVwPV92bS5fc2VsZi5fc2V0dXBQcm94eTtyZXR1cm4gX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwib3B0aW9ucy1jb250YWluZXJcIixhdHRyczp7XCJpZFwiOlwib3B0aW9uc0RpdlwifX0sW192bS5fbSgwKSxfdm0uX3YoXCIgXCIpLF9jKCdkaXYnLHtzdGF0aWNDbGFzczpcIm9wdGlvbnMtZm9ybVwifSxbX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwib3B0aW9uLXNlY3Rpb25cIn0sW19jKCdoMicse3N0YXRpY0NsYXNzOlwic2VjdGlvbi10aXRsZVwifSxbX3ZtLl92KFwiRGlzcGxheSBTZXR0aW5nc1wiKV0pLF92bS5fdihcIiBcIiksX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwic2VjdGlvbi1jb250ZW50XCJ9LFtfYygnZGl2Jyx7c3RhdGljQ2xhc3M6XCJzZXR0aW5nLXJvd1wiLGF0dHJzOntcInRpdGxlXCI6XCJEaXNwbGF5IHRoZSBmbG9hdGluZyBoZWxwIGJ1dHRvbiBvbiBUZXJyYWluIHBhZ2VzXCJ9fSxbX3ZtLl9tKDEpLF92bS5fdihcIiBcIiksX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwic2V0dGluZy1jb250cm9sXCJ9LFtfYygnbGFiZWwnLHtzdGF0aWNDbGFzczpcImNoZWNrYm94LWNvbnRhaW5lclwifSxbX2MoJ2lucHV0Jyx7YXR0cnM6e1widHlwZVwiOlwiY2hlY2tib3hcIixcIm5hbWVcIjpcImhlbHBidXR0b25cIixcImlkXCI6XCJoZWxwYnV0dG9uXCJ9LGRvbVByb3BzOntcImNoZWNrZWRcIjpfdm0uaGVscGJ1dHRvbn0sb246e1wiY2hhbmdlXCI6X3ZtLnVwZGF0ZUhlbHBCdXR0b259fSksX3ZtLl92KFwiIFwiKSxfYygnc3Bhbicse3N0YXRpY0NsYXNzOlwiY2hlY2ttYXJrXCJ9KSxfdm0uX3YoXCIgXCIpLF9jKCdzcGFuJyx7c3RhdGljQ2xhc3M6XCJjaGVja2JveC1sYWJlbFwifSxbX3ZtLl92KFwiU2hvdyBoZWxwIGJ1dHRvblwiKV0pXSldKV0pXSldKSxfdm0uX3YoXCIgXCIpLF9jKCdkaXYnLHtzdGF0aWNDbGFzczpcIm9wdGlvbi1zZWN0aW9uXCJ9LFtfYygnaDInLHtzdGF0aWNDbGFzczpcInNlY3Rpb24tdGl0bGVcIn0sW192bS5fdihcIkV2ZW50IERlZmF1bHQgU2V0dGluZ3NcIildKSxfdm0uX3YoXCIgXCIpLF9jKCdkaXYnLHtzdGF0aWNDbGFzczpcInNlY3Rpb24tY29udGVudFwifSxbX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwic2V0dGluZy1yb3dcIixhdHRyczp7XCJ0aXRsZVwiOlwiVGhlIGRlZmF1bHQgdGltZSBmb3IgbmV3IGNhbGVuZGFyIGV2ZW50c1wifX0sW192bS5fbSgyKSxfdm0uX3YoXCIgXCIpLF9jKCdkaXYnLHtzdGF0aWNDbGFzczpcInNldHRpbmctY29udHJvbFwifSxbX2MoJ2lucHV0Jyx7ZGlyZWN0aXZlczpbe25hbWU6XCJtb2RlbFwiLHJhd05hbWU6XCJ2LW1vZGVsXCIsdmFsdWU6KF92bS5kZWZhdWx0U3RhcnRUaW1lKSxleHByZXNzaW9uOlwiZGVmYXVsdFN0YXJ0VGltZVwifV0sc3RhdGljQ2xhc3M6XCJpbnB1dC1maWVsZCB0aW1lLWlucHV0XCIsYXR0cnM6e1widHlwZVwiOlwidGltZVwiLFwiaWRcIjpcImRlZmF1bHRTdGFydFRpbWVcIn0sZG9tUHJvcHM6e1widmFsdWVcIjooX3ZtLmRlZmF1bHRTdGFydFRpbWUpfSxvbjp7XCJjaGFuZ2VcIjpfdm0udXBkYXRlRGVmYXVsdFN0YXJ0VGltZSxcImlucHV0XCI6ZnVuY3Rpb24oJGV2ZW50KXtpZigkZXZlbnQudGFyZ2V0LmNvbXBvc2luZylyZXR1cm47X3ZtLmRlZmF1bHRTdGFydFRpbWU9JGV2ZW50LnRhcmdldC52YWx1ZX19fSldKV0pLF92bS5fdihcIiBcIiksX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwic2V0dGluZy1yb3dcIixhdHRyczp7XCJ0aXRsZVwiOlwiSG93IGxvbmcgbmV3IGV2ZW50cyBzaG91bGQgbGFzdCAoaW4gbWludXRlcylcIn19LFtfdm0uX20oMyksX3ZtLl92KFwiIFwiKSxfYygnZGl2Jyx7c3RhdGljQ2xhc3M6XCJzZXR0aW5nLWNvbnRyb2xcIn0sW19jKCdkaXYnLHtzdGF0aWNDbGFzczpcImlucHV0LWdyb3VwXCJ9LFtfYygnaW5wdXQnLHtkaXJlY3RpdmVzOlt7bmFtZTpcIm1vZGVsXCIscmF3TmFtZTpcInYtbW9kZWxcIix2YWx1ZTooX3ZtLmRlZmF1bHREdXJhdGlvbiksZXhwcmVzc2lvbjpcImRlZmF1bHREdXJhdGlvblwifV0sc3RhdGljQ2xhc3M6XCJpbnB1dC1maWVsZCBudW1iZXItaW5wdXRcIixhdHRyczp7XCJ0eXBlXCI6XCJudW1iZXJcIixcImlkXCI6XCJkZWZhdWx0RHVyYXRpb25cIixcIm1pblwiOlwiMTVcIixcIm1heFwiOlwiMTQ0MFwiLFwic3RlcFwiOlwiMTVcIn0sZG9tUHJvcHM6e1widmFsdWVcIjooX3ZtLmRlZmF1bHREdXJhdGlvbil9LG9uOntcImNoYW5nZVwiOl92bS51cGRhdGVEZWZhdWx0RHVyYXRpb24sXCJpbnB1dFwiOmZ1bmN0aW9uKCRldmVudCl7aWYoJGV2ZW50LnRhcmdldC5jb21wb3NpbmcpcmV0dXJuO192bS5kZWZhdWx0RHVyYXRpb249JGV2ZW50LnRhcmdldC52YWx1ZX19fSksX3ZtLl92KFwiIFwiKSxfYygnc3Bhbicse3N0YXRpY0NsYXNzOlwiaW5wdXQtYWRkb25cIn0sW192bS5fdihcIm1pbnV0ZXNcIildKV0pXSldKSxfdm0uX3YoXCIgXCIpLF9jKCdkaXYnLHtzdGF0aWNDbGFzczpcInNldHRpbmctcm93XCIsYXR0cnM6e1widGl0bGVcIjpcIlRoZSBkZWZhdWx0IGxvY2F0aW9uIGZvciBuZXcgY2FsZW5kYXIgZXZlbnRzXCJ9fSxbX3ZtLl9tKDQpLF92bS5fdihcIiBcIiksX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwic2V0dGluZy1jb250cm9sXCJ9LFtfYygnaW5wdXQnLHtkaXJlY3RpdmVzOlt7bmFtZTpcIm1vZGVsXCIscmF3TmFtZTpcInYtbW9kZWxcIix2YWx1ZTooX3ZtLmRlZmF1bHRMb2NhdGlvbiksZXhwcmVzc2lvbjpcImRlZmF1bHRMb2NhdGlvblwifV0sc3RhdGljQ2xhc3M6XCJpbnB1dC1maWVsZCB0ZXh0LWlucHV0XCIsYXR0cnM6e1widHlwZVwiOlwidGV4dFwiLFwiaWRcIjpcImRlZmF1bHRMb2NhdGlvblwiLFwicGxhY2Vob2xkZXJcIjpcIkVudGVyIGRlZmF1bHQgbG9jYXRpb25cIn0sZG9tUHJvcHM6e1widmFsdWVcIjooX3ZtLmRlZmF1bHRMb2NhdGlvbil9LG9uOntcImNoYW5nZVwiOl92bS51cGRhdGVEZWZhdWx0TG9jYXRpb24sXCJpbnB1dFwiOmZ1bmN0aW9uKCRldmVudCl7aWYoJGV2ZW50LnRhcmdldC5jb21wb3NpbmcpcmV0dXJuO192bS5kZWZhdWx0TG9jYXRpb249JGV2ZW50LnRhcmdldC52YWx1ZX19fSldKV0pXSldKV0pXSlcbn1cbnZhciBzdGF0aWNSZW5kZXJGbnMgPSBbZnVuY3Rpb24gKCl7dmFyIF92bT10aGlzLF9jPV92bS5fc2VsZi5fYyxfc2V0dXA9X3ZtLl9zZWxmLl9zZXR1cFByb3h5O3JldHVybiBfYygnZGl2Jyx7c3RhdGljQ2xhc3M6XCJwYWdlLWhlYWRlclwifSxbX2MoJ2gxJyx7c3RhdGljQ2xhc3M6XCJwYWdlLXRpdGxlXCJ9LFtfdm0uX3YoXCJPcHRpb25zXCIpXSksX3ZtLl92KFwiIFwiKSxfYygncCcse3N0YXRpY0NsYXNzOlwicGFnZS1kZXNjcmlwdGlvblwifSxbX3ZtLl92KFwiXFxuICAgICAgQ29uZmlndXJlIGhvdyBTdW1taXQgbG9va3MgYW5kIGJlaGF2ZXMuIFNldHRpbmdzIGFyZSBzYXZlZCBsb2NhbGx5IGluIHlvdXIgYnJvd3Nlci5cXG4gICAgXCIpXSldKVxufSxmdW5jdGlvbiAoKXt2YXIgX3ZtPXRoaXMsX2M9X3ZtLl9zZWxmLl9jLF9zZXR1cD1fdm0uX3NlbGYuX3NldHVwUHJveHk7cmV0dXJuIF9jKCdkaXYnLHtzdGF0aWNDbGFzczpcInNldHRpbmctbGFiZWxcIn0sW19jKCdsYWJlbCcse2F0dHJzOntcImZvclwiOlwiaGVscGJ1dHRvblwifX0sW192bS5fdihcIlRlcnJhaW4gSGVscCBCdXR0b25cIildKV0pXG59LGZ1bmN0aW9uICgpe3ZhciBfdm09dGhpcyxfYz1fdm0uX3NlbGYuX2MsX3NldHVwPV92bS5fc2VsZi5fc2V0dXBQcm94eTtyZXR1cm4gX2MoJ2Rpdicse3N0YXRpY0NsYXNzOlwic2V0dGluZy1sYWJlbFwifSxbX2MoJ2xhYmVsJyx7YXR0cnM6e1wiZm9yXCI6XCJkZWZhdWx0U3RhcnRUaW1lXCJ9fSxbX3ZtLl92KFwiRGVmYXVsdCBTdGFydCBUaW1lXCIpXSldKVxufSxmdW5jdGlvbiAoKXt2YXIgX3ZtPXRoaXMsX2M9X3ZtLl9zZWxmLl9jLF9zZXR1cD1fdm0uX3NlbGYuX3NldHVwUHJveHk7cmV0dXJuIF9jKCdkaXYnLHtzdGF0aWNDbGFzczpcInNldHRpbmctbGFiZWxcIn0sW19jKCdsYWJlbCcse2F0dHJzOntcImZvclwiOlwiZGVmYXVsdER1cmF0aW9uXCJ9fSxbX3ZtLl92KFwiRGVmYXVsdCBEdXJhdGlvblwiKV0pXSlcbn0sZnVuY3Rpb24gKCl7dmFyIF92bT10aGlzLF9jPV92bS5fc2VsZi5fYyxfc2V0dXA9X3ZtLl9zZWxmLl9zZXR1cFByb3h5O3JldHVybiBfYygnZGl2Jyx7c3RhdGljQ2xhc3M6XCJzZXR0aW5nLWxhYmVsXCJ9LFtfYygnbGFiZWwnLHthdHRyczp7XCJmb3JcIjpcImRlZmF1bHRMb2NhdGlvblwifX0sW192bS5fdihcIkRlZmF1bHQgTG9jYXRpb25cIildKV0pXG59XVxucmVuZGVyLl93aXRoU3RyaXBwZWQgPSB0cnVlXG5leHBvcnQgeyByZW5kZXIsIHN0YXRpY1JlbmRlckZucyB9Il0sIm5hbWVzIjpbImRlZmluZUNvbXBvbmVudCIsIkRFRkFVTFRfRVZFTlRfU0VUVElOR1MiLCJzdGFydFRpbWUiLCJkdXJhdGlvbiIsImxvY2F0aW9uIiwiZ2V0U3RvcmVkRXZlbnRTZXR0aW5nIiwia2V5IiwiZGVmYXVsdFZhbHVlIiwic3RvcmVkIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsImNvbmNhdCIsInBhcnNlSW50Iiwic3RvcmVFdmVudFNldHRpbmciLCJ2YWx1ZSIsInNldEl0ZW0iLCJ0b1N0cmluZyIsIndpbmRvdyIsImRpc3BhdGNoRXZlbnQiLCJDdXN0b21FdmVudCIsImRldGFpbCIsImRhdGEiLCJoZWxwYnV0dG9uIiwiJHN0b3JlIiwic3RhdGUiLCJTdW1taXQiLCJoZWxwQnV0dG9uIiwiZGVmYXVsdFN0YXJ0VGltZSIsImRlZmF1bHREdXJhdGlvbiIsImRlZmF1bHRMb2NhdGlvbiIsIm1ldGhvZHMiLCJ1cGRhdGVIZWxwQnV0dG9uIiwiZGlzcGF0Y2giLCJjb25zb2xlIiwibG9nIiwidXBkYXRlRGVmYXVsdFN0YXJ0VGltZSIsInVwZGF0ZURlZmF1bHREdXJhdGlvbiIsInVwZGF0ZURlZmF1bHRMb2NhdGlvbiIsImNvbXB1dGVkIiwiY29tcHV0ZWRNZXNzYWdlIiwiZ2V0dGVycyIsIndhdGNoIiwiJHN0b3JlLnN0YXRlLlN1bW1pdC5oZWxwQnV0dG9uIiwibmV3VmFsIiwibW91bnRlZCIsIiRudXh0IiwiZ2xvYmFsIiwiYnJlYWRjcnVtYnMiLCJ0ZXh0IiwiZGlzYWJsZWQiLCJ0byIsImV4YWN0Il0sInNvdXJjZVJvb3QiOiIifQ==