// Content script bridge between page context and extension background.
// Listens for window.postMessage events from the page and forwards them to chrome.runtime.
// Replies are posted back to the page via window.postMessage with the same requestId.

(function(){
  // Only run in content script environment
  if (typeof chrome === 'undefined' || !chrome.runtime) return;

  window.addEventListener('message', async (ev) => {
    try {
      const msg = ev.data;
      if (!msg || !msg.__terraflowBridge) return;

      const requestId = msg.requestId;
      const type = msg.type;

      // Forward to background
      chrome.runtime.sendMessage(msg, (resp) => {
        // Ensure we always reply to the page
        window.postMessage({ __terraflowBridgeResponse: true, requestId, resp }, '*');
      });
    } catch (err) {
      // On error, reply with error info
      try { window.postMessage({ __terraflowBridgeResponse: true, requestId: ev.data && ev.data.requestId, resp: { ok: false, error: String(err) } }, '*'); } catch (e) {}
    }
  }, false);
})();
